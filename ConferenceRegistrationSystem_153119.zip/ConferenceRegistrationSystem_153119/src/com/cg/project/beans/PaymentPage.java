package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class PaymentPage {

	@FindBy(how=How.ID,id="txtCardholderName")
	private WebElement cardHolgerName;
	
	@FindBy(how=How.ID,id="txtDebit")
	private WebElement debitNumber;
	
	@FindBy(how=How.ID,id="txtCvv")
	private WebElement cvv;
	
	@FindBy(how=How.ID,id="txtMonth")
	private WebElement expMonth;
	
	@FindBy(how=How.ID,id="txtYear")
	private WebElement expYear;
	
	@FindBy(how=How.ID,id="btnPayment")
	private WebElement payButton;
	
	public void clickPayButton() {
		payButton.click();
	}

	public String getCardHolgerName() {
		return cardHolgerName.getAttribute("value");
	}

	public void setCardHolgerName(String cardHolgerName) {
		this.cardHolgerName.sendKeys(cardHolgerName);
	}

	public String getDebitNumber() {
		return debitNumber.getAttribute("value");
	}

	public void setDebitNumber(String debitNumber) {
		this.debitNumber.sendKeys(debitNumber);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getExpMonth() {
		return expMonth.getAttribute("value");
	}

	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth);
	}

	public String getExpYear() {
		return expYear.getAttribute("value");
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}

}
