package com.cg.project.githubtepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {

	private WebDriver webdriver;
	@Before(order = 1)
	public void setUpStepEnv() {
		
		System.setProperty("webdriver.chrome.driver", "D:\\STS_Cucumber_plugin\\chromedriver.exe");
		System.out.println("setUpStepEnv");
		
	}
	
	@Given("^user want to access 'https://my\\.naukri\\.com/account/createaccount\\?othersrcp=(\\d+)&wExp=N'$")
	public void user_want_to_access_https_my_naukri_com_account_createaccount_othersrcp_wExp_N(int arg1) throws Throwable {
		webdriver = new ChromeDriver();
	}

	@When("^user open google chrome$")
	public void user_open_google_chrome() throws Throwable {
		webdriver.get("https://my.naukri.com/account/createaccount?othersrcp=11496&wExp=N");
	}

	@Then("^display the homepage of 'https://my\\.naukri\\.com/account/register/basicdetails'$")
	public void display_the_homepage_of_https_my_naukri_com_account_register_basicdetails() throws Throwable {
		webdriver.findElement(By.xpath("/html/body/div/form/div[1]/div/button")).click();
	
	}

	@Then("^user will enter 'Name' with 'SowmyaDhumale'$")
	public void user_will_enter_Name_with_SowmyaDhumale() throws Throwable {
		WebElement element1 = webdriver.findElement(By.id("fname"));
		element1.sendKeys("SowmyaDhumale");
	}

	@Then("^user will enter 'Email ID' with 'sowmyajnvn2012@gmail.com'$")
	public void user_will_enter_Email_ID_with_sowmyajnvn2012_gmail_com() throws Throwable {
		WebElement element1 = webdriver.findElement(By.id("email"));
		element1.sendKeys("sowmyajnvn2012@gmail.com");
	}

	@Then("^user will enter 'Create Password' with 'password'$")
	public void user_will_enter_Create_Password_with_password() throws Throwable {
		WebElement element1 = webdriver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/div[3]/div[1]/div/input"));
		element1.sendKeys("tinny13199");
	}

	@Then("^user will enter 'Mobile number' with '(\\d+)'$")
	public void user_will_enter_Mobile_number_with(int arg1) throws Throwable {
		WebElement element1 = webdriver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/div[4]/div[1]/div/input[2]"));
		element1.sendKeys("9989196932");
	}
	
	@Then("^user will select 'Current location'$")
	public void user_will_select_Current_location() throws Throwable {
		WebElement optionsList = webdriver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/resman-location/div/div/div[1]/div/div[1]/ul/li/div/label/input"));
		optionsList.sendKeys("Patna");
		optionsList.submit();
	}
	
	@Then("^user will 'Upload Resume'$")
	public void user_will_Upload_Resume() throws Throwable {
		WebElement element = webdriver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/resman-uploader/div/div[1]/span[1]/input"));
		element.sendKeys("D:\\Users\\adm-ig-hwdlab1c\\Downloads\\Dhumale Sowmya Resume.pdf");
		element.submit();
	}

	@Then("^user click on 'Register Now'$")
	public void user_click_on_Register_Now() throws Throwable {
		WebElement element2 = webdriver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/div[5]/div/div/div[2]/button"));
		element2.click();   
	}

	@Then("^user should see 'https://my\\.naukri\\.com/account/register/education'$")
	public void user_should_see_https_my_naukri_com_account_register_education() throws Throwable {
	   Thread.sleep(3000);
	   webdriver.navigate().refresh();
	}

	@Then("^user will choose 'Highest Qualification'$")
	public void user_will_choose_Highest_Qualification() throws Throwable {
	  webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[1]/ul/li/div/label/input")).click();
	  webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/edu-qualification/div/div[1]/div/div/div[2]/ul/li[4]/div/div/span")).click();
	  
	}

	@Then("^user will choose 'Board'$")
	public void user_will_choose_Board() throws Throwable {
	
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[1]/div/div/div/div[1]/ul/li/div/label/input")).click();
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[1]/div/div/div/div[2]/ul/li[2]/div/div/span")).click();
		  
	}

	@Then("^user will choose 'Year of Passing'$")
	public void user_will_choose_Year_of_Passing() throws Throwable {
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[2]/div/div/div/div[1]/ul/li/div/label/input")).click();
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[2]/div/div/div/div[2]/ul/li[2]/div/div/span")).click(); 
	}

	@Then("^user will choose 'Medium'$")
	public void user_will_choose_Medium() throws Throwable {
	
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[3]/div/div/div/div[1]/ul/li/div/label/input")).click();
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[3]/div/div/div/div[2]/ul/li[3]/div/div/span")).click(); 
	}

	@Then("^user will choose 'Percentage'$")
	public void user_will_choose_Percentage() throws Throwable {
		
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[4]/div/div/div/div[1]/ul/li/div/label/input")).click();
		webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/edu-section/section/div/resman-school-twelfth/div[4]/div/div/div/div[2]/ul/li[13]/div/div/span")).click();
	}

	@Then("^user will choose 'Skills'$")
	public void user_will_choose_Skills() throws Throwable {
		WebElement element = webdriver.findElement(By.xpath("//*[@id=\"selSkillCont\"]/div/ul/li/suggestor/div/div/input"));
		element.sendKeys("HTML");
		
	}

	@Then("^user click on 'Continue'$")
	public void user_click_on_Continue() throws Throwable {
		
		WebElement element = webdriver.findElement(By.xpath("//*[@id=\"educationDetailForm\"]/div/div/div/button"));
		element.click();
	   
	}

	@Then("^user should see 'https://my\\.naukri\\.com/account/register/profilecompletion'$")
	public void user_should_see_https_my_naukri_com_account_register_profilecompletion() throws Throwable {
	   
	}


}
