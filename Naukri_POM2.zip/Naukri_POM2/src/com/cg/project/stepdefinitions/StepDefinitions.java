package com.cg.project.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.RegistrationPage;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefinitions {

	private WebDriver webDriver;
	private RegistrationPage registrationPage;
	@Before(order=1)
	public void setUpStepEnv1() {		
		System.setProperty("webdriver.chrome.driver", "D:\\STS_Cucumber_plugin\\chromedriver.exe");
	}	

	@Given("^user want to access 'https://my\\.naukri\\.com/account/createaccount\\?othersrcp=(\\d+)&wExp=N'$")
	public void user_want_to_access_https_my_naukri_com_account_createaccount_othersrcp_wExp_N(int arg1) throws Throwable {
		webDriver = new ChromeDriver();
	}

	@When("^user open google chrome$")
	public void user_open_google_chrome() throws Throwable {
		webDriver.get("https://my.naukri.com/account/createaccount");
	}

	@Then("^display the homepage of 'https://my\\.naukri\\.com/account/register/basicdetails'$")
	public void display_the_homepage_of_https_my_naukri_com_account_register_basicdetails() throws Throwable {
		webDriver.findElement(By.xpath("/html/body/div/form/div[1]/div/button")).click();
		registrationPage = new RegistrationPage();
		PageFactory.initElements(webDriver, registrationPage);
	}

	@Then("^user will enter 'Name' with 'srilakshmikothuru'$")
	public void user_will_enter_Name_with_srilakshmikothuru() throws Throwable {
		registrationPage.setName("srilakshmikothuru");
	}

	@Then("^user will enter 'Email ID' with 'srilaxmikothuru(\\d+)@gmail\\.com'$")
	public void user_will_enter_Email_ID_with_srilaxmikothuru_gmail_com(int arg1) throws Throwable {
		registrationPage.setEmail("srilaxmikothuri7339344t@gmail.com");
	}

	@Then("^user will enter 'Create Password' with 'sri(\\d+)'$")
	public void user_will_enter_Create_Password_with_sri(int arg1) throws Throwable {
		registrationPage.setPassword("sri1234");
	}

	@Then("^user will enter 'Mobile number' with '(\\d+)'$")
	public void user_will_enter_Mobile_number_with(int arg1) throws Throwable {
		registrationPage.setMobileNo("9160538844");
	}

	@Then("^user will select 'Current location'$")
	public void user_will_select_Current_location() throws Throwable {
		registrationPage.setLocation("Coimbatore");
	}

	@Then("^user will 'Upload Resume'$")
	public void user_will_Upload_Resume() throws Throwable {
		registrationPage.setUploadResume("D:\\Users\\adm-ig-hwdlab1c\\Downloads\\Dhumale Sowmya Resume.pdf");

	}

	@Then("^user click on 'Register Now'$")
	public void user_click_on_Register_Now() throws Throwable {
		registrationPage.clickSubmitButton();
	}	

	@Then("^user should see 'https://my\\.naukri\\.com/account/register/education'$")
	public void user_should_see_https_my_naukri_com_account_register_education() throws Throwable {
		String actualTitle = webDriver.getTitle();
		String expectedTitle = "Resume Manager - Post Resume Online - Submit your CV - Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
		Thread.sleep(3000);
		//webDriver.navigate().refresh();
	}

	@Then("^user will choose 'Highest Qualification'$")
	public void user_will_choose_Highest_Qualification() throws Throwable {
		registrationPage.clickQualification();
		registrationPage.clickSelectQualification();

	}

	@Then("^user will choose 'Board'$")
	public void user_will_choose_Board() throws Throwable {		
		registrationPage.clickBoard();
		registrationPage.clickSelectBoard();
	}

	@Then("^user will choose 'Year of Passing'$")
	public void user_will_choose_Year_of_Passing() throws Throwable {
		registrationPage.clickYearOfPassing();
		registrationPage.clickSelectYearOfPassing();
	}

	@Then("^user will choose 'Medium'$")
	public void user_will_choose_Medium() throws Throwable {
		registrationPage.clickMedium();
		registrationPage.clickSelectMedium();
		
	}

	@Then("^user will choose 'Percentage'$")
	public void user_will_choose_Percentage() throws Throwable {
		registrationPage.clickPercentage();
		registrationPage.clickSelectPercentage();
	}

	@Then("^user will choose 'Skills'$")
	public void user_will_choose_Skills() throws Throwable {		
		registrationPage.setSkills("PHP");
	}

	@Then("^user click on 'Continue'$")
	public void user_click_on_Continue() throws Throwable {
		registrationPage.clickContinueButton();
	}

	@Then("^user should see 'https://my\\.naukri\\.com/account/register/profilecompletion'$")
	public void user_should_see_https_my_naukri_com_account_register_profilecompletion() throws Throwable {
		String actualTitle = webDriver.getTitle();
		String expectedTitle = "Resume Manager - Post Resume Online - Submit your CV - Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
		Thread.sleep(3000);
		webDriver.navigate().refresh();
	}

	@Then("^user click on 'Skip this step'$")
	public void user_click_on_Skip_this_step() throws Throwable {
		registrationPage.clickSkipStep();
	}

	@Then("^user should see 'https://www\\.naukri\\.com/free-job-alerts\\?src=DRES'$")
	public void user_should_see_https_www_naukri_com_free_job_alerts_src_DRES() throws Throwable {
		String actualTitle = webDriver.getTitle();
		String expectedTitle = "Free Job Alerts, Latest Jobs Alerts & Notification � Naukri.com";
		Assert.assertEquals(expectedTitle, actualTitle);
	}


}
