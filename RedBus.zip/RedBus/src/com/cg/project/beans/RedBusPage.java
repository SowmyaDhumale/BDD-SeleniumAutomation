package com.cg.project.beans;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RedBusPage {
	@FindBy(how=How.ID,id="src")
	//@FindBy(xpath="//*[@id=\"src\"]")
	WebElement from;

//	@FindBy(xpath="//*[@id=\"search\"]/div/div[1]/div/ul/li[1]")
//	WebElement selectFrom;

	@FindBy(how = How.ID, id = "dest")
	WebElement to;

//	@FindBy(xpath="//*[@id=\"search\"]/div/div[2]/div/ul/li[1]")
//	WebElement selectTo;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"search\"]/div/div[3]/div/label")
	WebElement date;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[4]/td[5]")
	WebElement selectDate;

	@FindBy(how = How.ID, id="search_btn")
	WebElement searchBusesButton;
	
	
	
	
	public RedBusPage() {
	}

	public String getFrom() {
		return this.from.getAttribute("value");
	}
	public void setFrom(String from) {
		this.from.sendKeys(from,Keys.ENTER);
	}
	public String getTo() {
		return this.to.getAttribute("value");
	}
	public void setTo(String to) {
		this.to.sendKeys(to,Keys.ENTER);
	}
	public String getDate() {
		return this.date.getAttribute("value");
	}
	public void setDate(String date) {
		this.date.sendKeys(date,Keys.ENTER);
	}
	public void clickSearchButton() {
		searchBusesButton.click();
	}

	public void clickdateButton() {
		date.click();
	}
	public void clickSearchdateButton() {
		selectDate.click();
	}

//	public void clickSearchfromButton() {
//		selectFrom.click();
//	}

//	public void clickSearchToButton() {
//		selectTo.click();
//	}

	public void clickfromButton() {
		from.click();
	}

	public void clickToButton() {
		to.click();
	}


}
