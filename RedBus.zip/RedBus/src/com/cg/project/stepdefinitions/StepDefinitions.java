package com.cg.project.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.RedBusPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
	private RedBusPage redbusPage;
	private ChromeDriver driver;
	@Before
	public void setupStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");

		//System.out.println("setupStepEnv()");
	}
	@Given("^user is on homepage of rebus$")
	public void user_is_on_homepage_of_rebus() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://www.redbus.in/");
		redbusPage = new RedBusPage();
		PageFactory.initElements(driver, redbusPage);


	}

	@When("^user enters From address$")
	public void user_enters_From_address() throws Throwable {
		redbusPage.setFrom("Pune");
		redbusPage.clickfromButton();
		//redbusPage.clickSearchfromButton();

	}

	@When("^enters to address$")
	public void enters_to_address() throws Throwable {
		redbusPage.setTo("Hyderabad");
		redbusPage.clickToButton();
		//redbusPage.clickSearchToButton();
	}

	@When("^selects onward date$")
	public void selects_onward_date() throws Throwable {
		redbusPage.clickdateButton();
		redbusPage.clickSearchdateButton();
	}

	@When("^clicks search buses$")
	public void clicks_search_buses() throws Throwable {
		driver.findElement(By.id("search_btn")).click();
	}

	@Then("^available buses page is displayed$")
	public void available_buses_page_is_displayed() throws Throwable {
		/*String actualTitle = driver.getTitle();
		String expectedTitle = "Search Bus Tickets";
		Assert.assertEquals(expectedTitle, actualTitle);
		Thread.sleep(3000);
		driver.navigate().refresh();*/
	}
}
